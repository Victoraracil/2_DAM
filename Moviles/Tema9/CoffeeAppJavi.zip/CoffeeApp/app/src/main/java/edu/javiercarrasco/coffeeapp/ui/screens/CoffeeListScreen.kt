package edu.javiercarrasco.coffeeapp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import edu.javiercarrasco.coffeeapp.ui.componentes.AppTopBar
import edu.javiercarrasco.coffeeapp.ui.componentes.CoffeeListItems
import edu.javiercarrasco.coffeeapp.ui.navigation.Screens

@Composable
fun CoffeeListScreen(
    navHostController: NavHostController,
    coffeeListViewModel: CoffeeListViewModel = viewModel()
) {
    val uiState by coffeeListViewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        // Cargar la lista de cafés al iniciar la pantalla y asegurarse de que se actualice
        // cada vez que se entre en esta pantalla para reflejar cambios en los comentarios.
        coffeeListViewModel.getCoffees()
    }

    AppTopBar(
        content = {
            Column(
                modifier = Modifier
                    .padding(it)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!uiState.isLoading) {
                    if (uiState.coffeeList.isEmpty()) {
                        Text(
                            modifier = Modifier.padding(16.dp),
                            text = uiState.errorMessage.toString(),
                            color = Color.Red
                        )
                        Button(
                            onClick = { coffeeListViewModel.getCoffees() }
                        ) { Text(text = "Reintentar") }
                    } else CoffeeListItems(
                        uiState.coffeeList,
                        {
                            navHostController.navigate(Screens.DetailCoffeeScreen.createRoute(it.id!!))
                        })
                } else {
                    CircularProgressIndicator(
                        modifier = Modifier.padding(16.dp)
                    )
                    Text(text = "Cargando cafés...")
                }
            }
        },
        actions = {
            IconButton(
                onClick = {
                    coffeeListViewModel.logout()
                    navHostController.navigate(Screens.LoginScreen.route) {
                        popUpTo(navHostController.graph.id) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout")
            }
        })
}
