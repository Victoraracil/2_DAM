package edu.javiercarrasco.coffeeapp.ui.screens

import android.app.Application
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import edu.javiercarrasco.coffeeapp.data.local.AppDatabase
import edu.javiercarrasco.coffeeapp.data.local.LocalDatasource
import es.javiercarrasco.ejemplologin.data.Repository
import es.javiercarrasco.ejemplologin.data.model.Coffee
import es.javiercarrasco.ejemplologin.data.model.LoginState
import es.javiercarrasco.ejemplologin.data.model.SessionManager
import es.javiercarrasco.ejemplologin.data.model.dataStore
import es.javiercarrasco.ejemplologin.data.remote.RemoteDataSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CoffeeListViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: Repository
    private val remoteDatasource: RemoteDataSource
    private val localDatasource: LocalDatasource
    private val sessionManager: SessionManager

    data class CoffeeListUiState(
        val coffeeList: List<Coffee> = emptyList(),
        val isLoading: Boolean = false,
        val errorMessage: String? = null,
        val loginState: LoginState = LoginState.Idle
    )

    private val _stateCoffeeList = MutableStateFlow<List<Coffee>>(emptyList())

    // Estado de la UI.
    val uiState: StateFlow<CoffeeListUiState>
    private val _isLoading = MutableStateFlow(false)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _loginState = MutableStateFlow<LoginState>(LoginState.Idle)

    init {
        val db = AppDatabase.getInstance(application)
        localDatasource = LocalDatasource(db.coffeesDao())
        remoteDatasource = RemoteDataSource()
        repository = Repository(localDatasource)

        val dataStore: DataStore<Preferences> = application.dataStore
        sessionManager = SessionManager(dataStore)

        uiState = combine(
            _stateCoffeeList,
            _isLoading,
            _errorMessage,
            _loginState
        ) { coffeeList, isLoading, errorMessage, loginState ->
            CoffeeListUiState(
                coffeeList = coffeeList,
                isLoading = isLoading,
                errorMessage = errorMessage,
                loginState = loginState
            )
            // Este segundo combine es necesario para añadir un sexto flow.
        }.stateIn(
            viewModelScope, SharingStarted.Eagerly, CoffeeListUiState()
        )

        getCoffees()
    }

    fun logout() {
        viewModelScope.launch {
            _loginState.value = LoginState.Idle
            sessionManager.clearSession()
        }
    }

    fun getCoffees() {
        _isLoading.value = true

        viewModelScope.launch {
            sessionManager.sessionFlow.collect {
                try {
                    it.first?.let {
                        _stateCoffeeList.value = repository.fetchCoffees(it)
                        // Aquí puedes manejar la lista de café obtenida.
                        Log.d(
                            "CoffeListViewModel",
                            "Cafés obtenidos: ${_stateCoffeeList.value.size}"
                        )
                    }
                } catch (e: Exception) {
                    Log.e("CoffeListViewModel", "Error al obtener el listado de cafés.", e)
                    _errorMessage.value = "Error al obtener el listado de cafés: ${e.message}"
                } finally {
                    _isLoading.value = false
                }
            }
        }
    }
}