package edu.javiercarrasco.coffeeapp.data.local

import es.javiercarrasco.ejemplologin.data.model.Coffee

class LocalDatasource(val coffeesDao: CoffeesDao) {
    val coffees = coffeesDao.getAllCoffees()

    suspend fun insertCoffees(coffees: List<Coffee>) {
        coffeesDao.insertCoffees(coffees)
    }
}