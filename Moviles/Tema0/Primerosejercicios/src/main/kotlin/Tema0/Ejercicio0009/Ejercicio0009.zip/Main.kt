package com.dam.Tema0.Ejercicio0009

fun main() {
    println("Coche 1")
    val coche1 = Coche("Ford", "Fiesta", "17/12/2020")
    println(coche1.toString())
    println()
    println("Coche 2")
    val coche2 = Coche("BMW", "Z3", "12/02/1997")
    println(coche2.toString())
}