package com.dam.Tema0.Ejercicio0010

fun main() {
    println("Libro 1")
    val libro1 = Libro("It", "Stephen King", "1986")
    println(libro1.toString())
    println()
    println("Libro 2")
    val libro2 = Libro("Javier Crrasco", "Desarrollo de aplicaciones moviles en Kotlin", "")
    println(libro2.toString())
    println()
    println("Libro 2")
    val libro3 = Libro("", "", "")
    println(libro3.toString())
}
