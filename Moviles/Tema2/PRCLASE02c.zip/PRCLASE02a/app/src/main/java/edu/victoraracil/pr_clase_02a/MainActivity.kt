package edu.victoraracil.pr_clase_02a

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import edu.victoraracil.pr_clase_02a.data.model.ItemData
import edu.victoraracil.pr_clase_02a.data.model.ItemData.Companion.itemIdCounter
import edu.victoraracil.pr_clase_02a.ui.theme.PRCLASE02aTheme
import edu.victoraracil.pr_clase_02a.ui.theme.components.ItemTarjeta
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PRCLASE02aTheme {

                val itemDataListState = remember {
                    mutableStateListOf(
                        ItemData(
                            ++itemIdCounter,
                            "Item $itemIdCounter",
                            "Descripción del item $itemIdCounter",
                            "https://picsum.photos/seed/$itemIdCounter/200/200"
                        ),
                        ItemData(
                            ++itemIdCounter,
                            "Item $itemIdCounter",
                            "Descripción del item $itemIdCounter",
                            "https://picsum.photos/seed/$itemIdCounter/200/200"
                        ),
                        ItemData(
                            ++itemIdCounter,
                            "Item $itemIdCounter",
                            "Descripción del item $itemIdCounter",
                            "https://picsum.photos/seed/$itemIdCounter/200/200"
                        )
                    )
                }

                val snackbarHostState = remember { SnackbarHostState() }
                val scope = rememberCoroutineScope()
                val context = LocalContext.current

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(stringResource(id = R.string.app_name)) }
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton(onClick = {
                            itemDataListState.add(
                                ItemData(
                                    ++itemIdCounter,
                                    "Item $itemIdCounter",
                                    "Descripción del item $itemIdCounter",
                                    "https://picsum.photos/seed/$itemIdCounter/200/200"
                                )
                            )
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Añadir elemento")
                        }
                    },
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
                ) { innerPadding ->
                    ListaPantalla(
                        items = itemDataListState,
                        onToggleFavorite = { clicked ->
                            val index = itemDataListState.indexOf(clicked)
                            if (index != -1) {
                                val actualizado = clicked.copy(isFavorite = !clicked.isFavorite)
                                itemDataListState[index] = actualizado
                            }
                        },
                        onClick = { item ->
                            Toast.makeText(
                                context,
                                "ID: ${item.id} - ${item.title}",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onLongClick = { item ->
                            // Eliminar y mostrar Snackbar
                            itemDataListState.remove(item)
                            scope.launch {
                                snackbarHostState.showSnackbar(
                                    context.getString(
                                        R.string.elemento_eliminado,
                                        item.id,
                                        item.title
                                    )
                                )
                            }
                        },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun ListaPantalla(
    items: List<ItemData>,
    onToggleFavorite: (ItemData) -> Unit,
    onClick: (ItemData) -> Unit,
    onLongClick: (ItemData) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(vertical = 8.dp)
    ) {
        items(items, key = { it.id }) { item ->
            ItemTarjeta(
                item = item,
                onToggleFavorite = onToggleFavorite,
                onClick = onClick,
                onLongClick = onLongClick
            )
        }
    }
}