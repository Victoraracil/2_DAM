package edu.victoraracil.pr_clase_06a

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import edu.victoraracil.pr_clase_06a.data.CarsDao
import edu.victoraracil.pr_clase_06a.data.CarsDatabase
import edu.victoraracil.pr_clase_06a.data.model.Brand
import edu.victoraracil.pr_clase_06a.data.model.Car
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var dao: CarsDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dao = CarsDatabase.getDatabase(this).carsDao()

        setContent {
            // Observamos los datos. Cuando la DB cambie, la UI se refresca sola.
            val listaRelacionada by dao.getCarsWithBrands().collectAsState(initial = emptyList())

            Scaffold(
                topBar = {
                    // Nota: En Material 3 se usa TopAppBar con scrollBehavior o CenterAlignedTopAppBar
                    Text(
                        text = "PR-CLASE-06a",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.headlineSmall
                    )
                }) { paddingValues ->
                Column(
                    modifier = Modifier
                        .padding(paddingValues)
                        .padding(16.dp)
                        .fillMaxSize()
                ) {
                    // Botón para insertar datos fijos
                    Button(
                        onClick = { probarRoom() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp) // Bordes redondeados como en tu imagen
                    ) {
                        Text("Datos de prueba")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // SECCIÓN EDITORIALES / MARCAS
                    Text(
                        text = "Marcas",
                        style = MaterialTheme.typography.titleLarge, // Reemplazo de h6
                        fontWeight = FontWeight.Bold
                    )

                    val marcasUnicas = listaRelacionada.map { it.brand }.distinctBy { it.idBrand }
                    marcasUnicas.forEach { brand ->
                        Text(text = "${brand.idBrand} - ${brand.name}")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // SECCIÓN SUPERHÉROES / COCHES
                    Text(
                        text = "Coches",
                        style = MaterialTheme.typography.titleLarge, // Reemplazo de h6
                        fontWeight = FontWeight.Bold
                    )

                    listaRelacionada.forEach { item ->
                        Text(text = "${item.car.idCar} - ${item.car.model}")

                        // REQUISITO: Mostrar en logs la relación para confirmar funcionamiento
                        Log.d(
                            "ROOM_TEST",
                            "Relación confirmada: Coche [${item.car.model}] -> Marca [${item.brand.name}]"
                        )
                    }
                }
            }
        }
    }

    private fun probarRoom() {
        lifecycleScope.launch(Dispatchers.IO) {
            // Marcas
            dao.insertBrand(Brand(idBrand = 1, name = "Toyota"))
            dao.insertBrand(Brand(idBrand = 2, name = "Ford"))

            // Coches
            dao.insertCar(Car(model = "Corolla", motor = "Hybrid", year = 2022, idBrand = 1))
            dao.insertCar(Car(model = "Focus", motor = "Diesel", year = 2020, idBrand = 2))

            Log.d("ROOM_TEST", "Datos insertados correctamente")
        }
    }
}