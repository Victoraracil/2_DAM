package com.accesoadatos.biblioteca_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
