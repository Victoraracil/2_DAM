package com.dam;

public class Main {
    public static void main(String[] args) {
        SetPerformance setPerformance = new SetPerformance();
        setPerformance.setperformance();
    }
}