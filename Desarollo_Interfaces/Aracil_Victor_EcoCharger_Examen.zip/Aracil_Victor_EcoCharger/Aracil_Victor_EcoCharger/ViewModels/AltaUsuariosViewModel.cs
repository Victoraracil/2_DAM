﻿using Aracil_Victor_EcoCharger.Models;
using Aracil_Victor_EcoCharger.Services;
using Aracil_Victor_EcoCharger.ViewModels.Base;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Aracil_Victor_EcoCharger.ViewModels
{
    class AltaUsuariosViewModel : BaseViewModel
    {
        #region atributos
        private List<User> _listaUsuarios;
        private ObservableCollection<User> _listaUsuariosVisibles;

        // Declaramos un objeto de tipo Estacion para la estacion que manipulamos en el CRUD
        private User _usuario;

        // Declaramos un objeto de tipo Estacion para la seleccionada
        private User _selected;
        #endregion

        #region propiedades
        // ID de la Estacion con la que trabajamos
        public int Id
        {
            get { return _usuario.Id; }
            set { _usuario.Id = value; OnPropertyChanged(); }
        }

        // NOMBRE de la estacion con la que trabajamos
        public string FullName
        {
            get { return _usuario.FullName; }
            set { _usuario.FullName = value; OnPropertyChanged(); }
        }

        // DIRECCION de la estacion con la que trabajamos
        public string Email
        {
            get { return _usuario.Email; }
            set { _usuario.Email = value; OnPropertyChanged(); }
        }

        // DIRECCION de la estacion con la que trabajamos
        public string RFIDTag
        {
            get { return _usuario.RFIDTag; }
            set { _usuario.RFIDTag = value; OnPropertyChanged(); }
        }

        // DIRECCION de la estacion con la que trabajamos
        public int Telefono
        {
            get { return _usuario.Telefono; }
            set { _usuario.Telefono = value; OnPropertyChanged(); }
        }

        // IsACTIVE de la estacion con la que trabajamos
        public decimal Balance
        {
            get { return _usuario.Balance; }
            set { _usuario.Balance = value; OnPropertyChanged(); }
        }


        // Lista de estaciones
        public ObservableCollection<User> ListaUsuariosVisibles
        {
            get => _listaUsuariosVisibles;
            set => SetProperty(ref _listaUsuariosVisibles, value);
        }

        // Estacion seleccionada
        public User Selected
        {
            get => _selected;
            set => SetProperty(ref _selected, value);
        }
        #endregion

        #region constructor
        // Declaramos los diferentes ICommands
        public ICommand CargarCommand { get; }
        public ICommand NuevoUsuarioCommand { get; }
        public ICommand GuardarUsuarioCommand { get; }
        public ICommand BorrarUsuarioCommand { get; }
        public ICommand SelectedItemChangedCommand { get; }


        public AltaUsuariosViewModel()
        {
            // Inicializamos los atributos
            _listaUsuarios = new();
            _listaUsuariosVisibles = new();
            _usuario = new User();
            _selected = new User();

            // Inicializamos la lista de estaciones visibles
            ListaUsuariosVisibles = new ObservableCollection<User>();

            // Inicializamos los comandos
            CargarCommand = new RelayCommand(PerformCargarUsuarios);
            NuevoUsuarioCommand = new RelayCommand(PerformNuevoUsuario);
            GuardarUsuarioCommand = new RelayCommand(PerformGuardarUsuario, CanExecuteBotones);
            BorrarUsuarioCommand = new RelayCommand(PerformBorrarUsuario, CanExecuteBotones);
            SelectedItemChangedCommand = new RelayCommand(PerformSelectedItemChanged);
        }

        #endregion

        #region metodos
        // CanExecuteBotones
        private bool CanExecuteBotones(object? parameter)
        {
            //Debug.WriteLine("CanExecuteBotones");

            // Comprbamos que siempre haya un nombre de Estacion
            bool res = !string.IsNullOrWhiteSpace(FullName);
            return res;
        }

        // Cargamos las Estaciones
        private async void PerformCargarUsuarios(object? parameter = null)
        {
            // Abrimos una conexion con la BBDD
            var service = new ServiceUser();

            // Cargamos las estaciones desde la BBDD
            _listaUsuarios = await service.Listar();

            // Cargamos las estaciones en la ObservableCollection
            ListaUsuariosVisibles.Clear();
            foreach (var s in _listaUsuarios)
            {
                ListaUsuariosVisibles.Add(s);
            }
        }

        // Guardamos la estacione que estamos editando
        private async void PerformGuardarUsuario(object? parameter = null)
        {
            // Nos conectamos a la BBDD
            var service = new ServiceUser();

            // Guardamos los cambios dependiendo de si es una nueva estacion o una modificada
            if (Id == 0)
            {
                // Insertamos la nueva estacion
                var nuevoUsusario = await service.Insertar(_usuario);
                Id = nuevoUsusario.Id;
            }
            else
            {
                var nuevoUsusario = await service.Actualizar(_usuario);
            }

            PerformCargarUsuarios();
        }

        // Borramos la estacion que estamos editando
        private async void PerformBorrarUsuario(object? parameter = null)
        {
            // Nos conectamos a la BBDD
            var service = new ServiceUser();

            // Eliminamos la estacion seleccionada
            var sesionBorrada = await service.Borrar(Id);

            // Recargamos la lista
            PerformCargarUsuarios();
            PerformLimpiarUsuarios();
        }


        // Añadimos una nueva estacion

        private void PerformNuevoUsuario(object? parameter = null)
        {
            // Inicializamos una nueva estacion
            Id = 0;
            FullName = string.Empty;
            Email = string.Empty;
            RFIDTag = string.Empty;
            Telefono = 0;
            Balance = 0;

        }




        // Manejador de cambio de Item en la lista de estaciones
        private void PerformSelectedItemChanged(object? parameter = null)
        {
            // Comprobamos que haya un objeto seleccionado
            if (parameter != null)
            {
                Id = Selected.Id;
                FullName = Selected.FullName;
                Email = Selected.Email;
                RFIDTag = Selected.RFIDTag;
                Telefono = Selected.Telefono;
                Balance = Selected.Balance;
            }
        }

        // Limpiador de Interfaz
        private void PerformLimpiarUsuarios(object? parameter = null)
        {
            Id = 0;
            FullName = string.Empty;
            Email = string.Empty;
            RFIDTag = string.Empty;
            Telefono = 0;
            Balance = 0;
        }

        #endregion
    }
}
