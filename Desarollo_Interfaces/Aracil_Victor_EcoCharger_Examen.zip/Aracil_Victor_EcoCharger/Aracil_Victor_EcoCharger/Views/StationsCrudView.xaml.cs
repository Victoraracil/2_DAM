﻿using Aracil_Victor_EcoCharger.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Aracil_Victor_EcoCharger.Views
{
    /// <summary>
    /// Lógica de interacción para StationsCrudView.xaml
    /// </summary>
    public partial class StationsCrudView : UserControl
    {
        public StationsCrudView()
        {
            InitializeComponent();
            DataContext = new StationsCrudViewModel();
        }
    }
}
