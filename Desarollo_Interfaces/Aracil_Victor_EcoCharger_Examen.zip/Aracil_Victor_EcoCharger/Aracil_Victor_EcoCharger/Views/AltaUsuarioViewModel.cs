﻿namespace Aracil_Victor_EcoCharger.Views
{
    internal class AltaUsuarioViewModel
    {
        public AltaUsuarioViewModel()
        {
        }
    }
}