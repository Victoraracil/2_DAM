﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Aracil_Victor_GestionTareas03._01
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    /// <author> Victor Aracil Gozalvez</author>
    public partial class App : Application
    {
    }

}
