# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class Competicion(models.Model):
    _name = 'enduro.competicion'
    _description = 'Competición de Enduro'
    _rec_name = 'nombre'

    # Campos del modelo Competición
    nombre = fields.Char(string='Nombre de la competición', required=True)
    fecha = fields.Date(string='Fecha de la competición', required=True)
    tipo_terreno = fields.Selection(
        [('montana', 'Montaña'),
         ('bosque', 'Bosque'),
         ('rambla', 'Rambla'),
         ('mixto', 'Mixto')],
        string='Tipo de terreno'
    )
    numero_max_participantes = fields.Integer(string='Número máximo de participantes')
    descripcion = fields.Text(string='Descripción')

    # Relación con participantes
    participante_ids = fields.One2many('enduro.participante', 'competicion_id', string='Participantes')