from odoo import models, fields, api
from odoo.exceptions import ValidationError

class Participante(models.Model):
    _name = 'enduro.participante'
    _description = 'Participante de Enduro'
    _rec_name = 'nombre'

    # Campos del modelo Participante
    nombre = fields.Char(string='Nombre del participante', required=True)
    moto = fields.Char(string='Moto')
    categoria = fields.Selection(
        [('profesional', 'Profesional'),
         ('amateur', 'Amateur')],
        string='Categoría'
    )
    edad = fields.Integer(string='Edad')
    ha_finalizado = fields.Boolean(string='¿Ha finalizado la carrera?')

    # Relación Many2one con Competición
    competicion_id = fields.Many2one('enduro.competicion', string='Competición')
