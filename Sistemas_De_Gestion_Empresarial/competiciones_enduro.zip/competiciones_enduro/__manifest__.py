{
    'name': "competiciones_enduro",

    'summary': "Gestionar una liga de competociones enduro",

    'description': """
    Gestionar una liga de competociones enduro
    """,

    'installable': True,
    'application': True,
    'auto_install': False,
    'author': "Victor",
    'website': "",
    

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Tools',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/formulario_competicion.xml',
        'views/formulario_participante.xml',
        'views/menu.xml',
    ],
}

